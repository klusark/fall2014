#pragma once

// see the corresponding C++ file to see what they do
void save_image();
void histogram_normalization();
