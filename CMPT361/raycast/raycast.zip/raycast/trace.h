#pragma once

void ray_trace();
