#pragma once

#define WIN_WIDTH 512
#define WIN_HEIGHT 512
#define STOCH_RAYS 5

#define IMAGE_WIDTH 5.0
